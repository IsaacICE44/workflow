"""Compression Store for CCR (Compress-Cache-Retrieve) architecture.

This module implements reversible compression: when SmartCrusher compresses
tool outputs, the original data is cached here for on-demand retrieval.

Key insight from research: REVERSIBLE compression beats irreversible compression.
If the LLM needs data that was compressed away, it can retrieve it instantly.

Features:
- Thread-safe in-memory storage with TTL expiration
- BM25-based search within cached content
- Retrieval event tracking for feedback loop
- Automatic eviction when capacity is reached

Usage:
    store = get_compression_store()

    # Store compressed content
    hash_key = store.store(
        original=original_json,
        compressed=compressed_json,
        original_tokens=1000,
        compressed_tokens=100,
        tool_name="search_api",
    )

    # Retrieve later (by hash; always returns the full original content)
    entry = store.retrieve(hash_key)
"""

from __future__ import annotations

import hashlib
import heapq
import json
import logging
import os
import re
import threading
import time
from collections import deque
from contextvars import ContextVar
from dataclasses import asdict, dataclass, field, replace
from typing import TYPE_CHECKING, Any

from ..exceptions import StorageError
from ..log_safety import describe_exception, safe_id

if TYPE_CHECKING:
    from ..memory.tracker import ComponentStats
    from .backends import CompressionStoreBackend

logger = logging.getLogger(__name__)

DEFAULT_CCR_TTL_SECONDS = 1800  # session-scale; override via HEADROOM_CCR_TTL_SECONDS
CCR_TTL_SECONDS_ENV = "HEADROOM_CCR_TTL_SECONDS"

_RETRIEVAL_LOG_PREVIEW_CHARS = 4096
# Previews carry verbatim tool-result content (post-redaction) — source code,
# credentials the redactor does not recognize, customer data. That is not
# something the always-on runtime log should hold, so previews are OFF unless
# an operator turns them on with 1/true/yes/on; the log then records byte
# counts only. (The log file is created owner-only either way — see
# ``headroom/proxy/helpers.py:_OwnerOnlyRotatingFileHandler`` — because other
# switches put request content in the same file. That is a second line of
# defence, not a reason to log the payload.)
PAYLOAD_PREVIEW_ENV = "HEADROOM_LOG_PAYLOAD_PREVIEW"
_SECRET_KEY_VALUE_RE = re.compile(
    r"(?i)\b([A-Z0-9_-]*(?:API[_-]?KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|AUTH)[A-Z0-9_-]*)"
    r"(\s*[:=]\s*)([\"']?)([^\"'\s,}]+)"
)
_AUTH_VALUE_RE = re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{12,}")
_API_KEY_VALUE_RE = re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b")
# Exactly one CCR marker and nothing else (see ``store`` and #2694, #4266).
_BARE_CCR_MARKER_RE = re.compile(r"<<ccr:[^>\n]+>>")


def _get_env_default_ttl_seconds() -> int:
    raw_value = os.environ.get(CCR_TTL_SECONDS_ENV)
    if raw_value is None or not raw_value.strip():
        return DEFAULT_CCR_TTL_SECONDS

    try:
        ttl_seconds = int(raw_value)
    except ValueError:
        logger.warning(
            "%s must be a positive integer number of seconds, got %r; using %s",
            CCR_TTL_SECONDS_ENV,
            raw_value,
            DEFAULT_CCR_TTL_SECONDS,
        )
        return DEFAULT_CCR_TTL_SECONDS

    if ttl_seconds <= 0:
        logger.warning(
            "%s must be greater than 0, got %s; using %s",
            CCR_TTL_SECONDS_ENV,
            ttl_seconds,
            DEFAULT_CCR_TTL_SECONDS,
        )
        return DEFAULT_CCR_TTL_SECONDS

    return ttl_seconds


def format_retrieval_miss_detail(status: dict[str, Any]) -> str:
    """Return an operator-facing miss reason for CCR retrieval failures."""
    default_ttl = status.get("default_ttl_seconds", DEFAULT_CCR_TTL_SECONDS)
    ttl_seconds = status.get("ttl_seconds", default_ttl)

    if status.get("status") == "expired":
        age_seconds = status.get("age_seconds")
        if isinstance(age_seconds, (int, float)):
            return f"Entry expired (CCR TTL: {ttl_seconds} seconds; age: {age_seconds:.0f} seconds)"
        return f"Entry expired (CCR TTL: {ttl_seconds} seconds)"

    return f"Entry not found (CCR TTL: {default_ttl} seconds)"


def _redact_retrieval_log_payload(payload: str) -> str:
    redacted = _SECRET_KEY_VALUE_RE.sub(r"\1\2\3[REDACTED]", payload)
    redacted = _AUTH_VALUE_RE.sub(r"\1 [REDACTED]", redacted)
    return _API_KEY_VALUE_RE.sub("sk-[REDACTED]", redacted)


def _payload_preview_enabled() -> bool:
    """True only when an operator has explicitly opted in. Default: off."""
    raw = os.environ.get(PAYLOAD_PREVIEW_ENV)
    if raw is None:
        return False
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _payload_for_retrieval_log(payload: str) -> dict[str, Any]:
    if not _payload_preview_enabled():
        return {
            "payload_chars": len(payload),
            "payload_preview_chars": 0,
            "payload_truncated": len(payload) > 0,
            "payload_preview": "",
        }
    redacted = _redact_retrieval_log_payload(payload)
    preview = redacted[:_RETRIEVAL_LOG_PREVIEW_CHARS]
    truncated = len(redacted) > len(preview)
    return {
        "payload_chars": len(payload),
        "payload_preview_chars": len(preview),
        "payload_truncated": truncated,
        "payload_preview": preview,
    }


# Single source of truth for the retrieval-miss message. Actionable by
# design: the model still has the marker in context (Read markers carry
# the file path), so tell it how to recover instead of just reporting
# the miss.
CCR_MISS_MESSAGE = (
    "Entry not found or expired. To recover: if the compression marker "
    "references a file Read, re-read that file (the path is in the "
    "marker; disk is the source of truth). If it was command output, "
    "re-run the command. Entries expire after the store TTL "
    "(default 30 minutes; configurable via HEADROOM_CCR_TTL_SECONDS)."
)


@dataclass
class CompressionEntry:
    """A cached compression entry with metadata for retrieval and feedback."""

    hash: str
    original_content: str
    compressed_content: str
    original_tokens: int
    compressed_tokens: int
    original_item_count: int
    compressed_item_count: int
    tool_name: str | None
    tool_call_id: str | None
    query_context: str | None
    created_at: float
    ttl: int = DEFAULT_CCR_TTL_SECONDS

    # TOIN integration: Store the tool signature hash for retrieval correlation
    # This MUST match the hash used by SmartCrusher when recording compression
    tool_signature_hash: str | None = None
    compression_strategy: str | None = None  # Strategy used for compression

    # Feedback tracking
    retrieval_count: int = 0
    search_queries: list[str] = field(default_factory=list)
    last_accessed: float | None = None

    def is_expired(self) -> bool:
        """Check if this entry has expired."""
        return time.time() - self.created_at > self.ttl

    def record_access(self, query: str | None = None) -> None:
        """Record an access to this entry for feedback tracking."""
        self.retrieval_count += 1
        self.last_accessed = time.time()
        if query and query not in self.search_queries:
            self.search_queries.append(query)
            # Keep only last 10 queries
            if len(self.search_queries) > 10:
                self.search_queries = self.search_queries[-10:]


@dataclass
class RetrievalEvent:
    """Event logged when content is retrieved from cache."""

    hash: str
    query: str | None
    items_retrieved: int
    total_items: int
    tool_name: str | None
    timestamp: float
    retrieval_type: str  # always "full" (retrieval is by hash)
    tool_signature_hash: str | None = None  # For TOIN correlation


class CompressionStore:
    """Thread-safe store for compressed content with retrieval support.

    This is the core of the CCR architecture. When SmartCrusher compresses
    an array, the original content is stored here. If the LLM needs more
    data, it can retrieve from this cache instantly.

    Design principles:
    - Zero external dependencies (pure Python)
    - Thread-safe for concurrent access
    - TTL-based expiration (default 300 seconds, env-configurable)
    - LRU-style eviction when capacity is reached
    - Hash-keyed retrieval that always returns the full original content
    """

    def __init__(
        self,
        max_entries: int = 1000,
        default_ttl: int = DEFAULT_CCR_TTL_SECONDS,
        enable_feedback: bool = True,
        backend: CompressionStoreBackend | None = None,
    ):
        """Initialize the compression store.

        Args:
            max_entries: Maximum number of entries to store.
            default_ttl: Default TTL in seconds (default 30 minutes — session scale).
            enable_feedback: Whether to track retrieval events.
            backend: Storage backend to use. Defaults to InMemoryBackend
                     when constructed directly; `get_compression_store()`
                     defaults to SQLiteBackend for restart/multi-worker
                     safety. Custom backends can be passed for
                     persistence (MongoDB, Redis).
        """
        # Import here to avoid circular imports
        from .backends import InMemoryBackend

        self._backend: CompressionStoreBackend = backend or InMemoryBackend()
        self._lock = threading.Lock()
        self._max_entries = max_entries
        self._default_ttl = default_ttl
        self._enable_feedback = enable_feedback

        # Feedback tracking. maxlen caps the display history, replacing an
        # append-then-reslice that re-copied 1000 pointers on every retrieval.
        self._max_events = 1000  # Keep last 1000 events
        self._retrieval_events: deque[RetrievalEvent] = deque(maxlen=self._max_events)
        # Deliberately NOT bounded: this is a drain-by-swap queue, and every
        # event in it still owes a feedback notification.
        self._pending_feedback_events: list[RetrievalEvent] = []

        # MEDIUM FIX #16: Use a min-heap for O(log n) eviction instead of O(n)
        # Heap entries are (created_at, hash_key) tuples
        self._eviction_heap: list[tuple[float, str]] = []
        # Expiration ordering is separate so live eviction stays oldest-first.
        self._expiration_heap: list[tuple[float, float, str]] = []
        # CRITICAL FIX: Track stale entries count to know when heap cleanup is needed
        self._stale_heap_entries = 0
        self._stale_expiration_heap_entries = 0
        # Threshold for triggering heap rebuild (when 50% are stale)
        self._heap_rebuild_threshold = 0.5
        external_revision = getattr(self._backend, "external_revision", None)
        self._backend_revision_reader = external_revision if callable(external_revision) else None
        # A backend that expires entries itself and is shared by replicas
        # (Redis) is bounded by TTL, not by this process's max_entries: counting
        # it on every store would scan the shared keyspace, and evicting would
        # remove other replicas' live entries.
        self._backend_expires_entries = bool(getattr(self._backend, "expires_entries", False))
        # A shared store's totals, as this process contributed them since it
        # started: [original tokens stored, compressed tokens stored, retrievals].
        self._own_totals = [0, 0, 0]
        self._backend_revision = self._read_backend_revision()

    @property
    def default_ttl_seconds(self) -> int:
        """Default TTL applied to new entries when callers do not override it."""
        return self._default_ttl

    def store(
        self,
        original: str,
        compressed: str,
        *,
        original_tokens: int = 0,
        compressed_tokens: int = 0,
        original_item_count: int = 0,
        compressed_item_count: int = 0,
        tool_name: str | None = None,
        tool_call_id: str | None = None,
        query_context: str | None = None,
        tool_signature_hash: str | None = None,
        compression_strategy: str | None = None,
        ttl: int | None = None,
        explicit_hash: str | None = None,
    ) -> str:
        """Store compressed content and return hash for retrieval.

        Args:
            original: Original JSON content before compression.
            compressed: Compressed JSON content.
            original_tokens: Token count of original content.
            compressed_tokens: Token count of compressed content.
            original_item_count: Number of items in original array.
            compressed_item_count: Number of items after compression.
            tool_name: Name of the tool that produced this output.
            tool_call_id: ID of the tool call.
            query_context: User query context for relevance matching.
            tool_signature_hash: Hash from ToolSignature for TOIN correlation.
            compression_strategy: Strategy used for compression.
            ttl: Custom TTL in seconds (uses default if not specified).
            explicit_hash: Use this exact hex hash as the storage key
                instead of computing SHA-256(original)[:24]. Required when
                the marker that points at this entry was emitted by a
                producer with its own hash function (e.g. SmartCrusher's
                Rust row-drop path uses SHA-256[:12]). If not a hex
                string, raises ``ValueError``. The marker hash and the
                store key MUST match — otherwise ``/v1/retrieve/{hash}``
                returns 404 even though the data is present.

        Returns:
            Hash key for retrieving this content.

        Raises:
            StorageError: The backend did not keep the entry (a shared store
                refused the write or was unreachable). No hash is issued for
                it: the caller must keep the original rather than emit a marker.
        """
        # Generate hash from original content. Default: SHA-256[:24] of the
        # original. When the caller provides `explicit_hash`, use it
        # verbatim — required when the hash that ends up in the prompt
        # marker is produced by another component (e.g. the Rust
        # SmartCrusher row-drop path emits SHA-256[:12], which the
        # Python store has to mirror so /v1/retrieve resolves it).
        # 24 chars (96 bits) was chosen for collision resistance under the
        # birthday bound: 50% collision probability at ~280 trillion entries
        # (2^48), versus ~4 billion (2^32) for the previous 16-char default.
        if explicit_hash is not None:
            # Validate as hex. Bail loudly per `feedback_no_silent_fallbacks`
            # — silently falling back to the default hash when the caller
            # asked for a specific key would defeat the marker/store
            # consistency we're trying to preserve.
            if not explicit_hash or not all(c in "0123456789abcdefABCDEF" for c in explicit_hash):
                raise ValueError(
                    f"explicit_hash must be a non-empty hex string, got {explicit_hash!r}"
                )
            hash_key = explicit_hash.lower()
        else:
            # SHA-256 truncated to 24 hex chars (96 bits) — same collision
            # space as the MD5[:24] this replaced. Switched from MD5 in
            # PR #395 to silence CodeQL's `py/weak-sensitive-data-hashing`
            # rule (the `usedforsecurity=False` parameter and the `lgtm`
            # comment marker both failed to suppress it). The cache is
            # in-memory, so changing the hash function on upgrade has no
            # persistence-side effect — the same content always hashes
            # deterministically under whichever function is in use.
            hash_key = hashlib.sha256(original.encode()).hexdigest()[:24]

        # Refuse to persist a bare CCR marker as an entry's "original"
        # (#2694). A marker is a *pointer* to content, never content: an
        # entry like `hash=abc123 -> "<<ccr:abc123,base64,2.0KB>>"` answers a
        # retrieve with the very placeholder the caller is trying to resolve,
        # and (worse) can overwrite a good entry with a useless one. Any
        # producer that gets here has lost the source bytes upstream, so fail
        # loudly rather than silently converting "retrievable" into "gone".
        # Narrow by design: only a *bare* marker is rejected. Legitimate
        # originals may legally CONTAIN markers (nested offloads, a tool that
        # echoed one), and refusing those would drop recoverable data. That
        # includes an original that starts with one marker and ends with
        # another (#4266), so the check is a full match of a single marker.
        #
        # The rejected value is never echoed into the log. It is provably a
        # bare marker here, but `original` is the store's credential-bearing
        # payload in the general case (this issue was reported against an
        # OAuth token), and an error path is exactly where that sort of leak
        # survives review. `hash_key` already identifies the entry.
        stripped = original.strip()
        if _BARE_CCR_MARKER_RE.fullmatch(stripped):
            logger.error(
                "CCR store: refusing to persist a bare retrieval marker as "
                "original_content (hash=%s tool=%s strategy=%s len=%d) — the "
                "producer lost the source bytes; retrieval for this hash will "
                "miss instead of returning a placeholder",
                hash_key,
                tool_name,
                compression_strategy,
                len(stripped),
            )
            return hash_key

        entry = CompressionEntry(
            hash=hash_key,
            original_content=original,
            compressed_content=compressed,
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            original_item_count=original_item_count,
            compressed_item_count=compressed_item_count,
            tool_name=tool_name,
            tool_call_id=tool_call_id,
            query_context=query_context,
            created_at=time.time(),
            ttl=ttl if ttl is not None else self._default_ttl,
            tool_signature_hash=tool_signature_hash,
            compression_strategy=compression_strategy,
        )
        expires_at = self._expiration_time(entry)

        # Process pending feedback BEFORE acquiring lock for eviction.
        # This ensures feedback from entries about to be evicted is captured.
        if self._enable_feedback:
            self.process_pending_feedback()

        with self._lock:
            # Decide whether this is a NEW key before evicting. Evicting to make
            # room only applies to a genuinely new entry; a re-store of an
            # existing key overwrites in place (no room needed). Evicting first
            # for a duplicate would needlessly destroy a live, unrelated entry
            # and drop the store below capacity, making that entry's <<ccr:...>>
            # marker (still sitting in the conversation) unredeemable — a 404.
            # The CCR mirror bridge re-stores the same explicit_hash on every
            # turn a marker is re-encountered, so duplicate stores are common.
            existing = self._backend.get(hash_key)
            if existing is None:
                if not self._backend_expires_entries:
                    self._evict_if_needed()
            else:
                # Hash already present. Different content means a true (extremely
                # rare with SHA256[:24]) collision; same content is a duplicate
                # re-store. Either way we overwrite in place.
                if existing.original_content != original:
                    logger.warning(
                        "Hash collision detected: hash=%s tool=%s (existing_len=%d, new_len=%d)",
                        hash_key,
                        tool_name,
                        len(existing.original_content),
                        len(original),
                    )
                else:
                    logger.debug(
                        "Duplicate store for hash=%s, updating entry",
                        hash_key,
                    )
                # Mark old heap entry as stale since we're replacing it.
                self._mark_heap_entries_stale()

            if self._backend.set(hash_key, entry) is False:
                # Only a backend that absorbs its errors (Redis) returns False;
                # it has logged why. A hash here would be a marker that never
                # resolves, and producers drop the original once they hold one.
                raise StorageError(
                    f"CCR store did not keep hash={hash_key}; keep the original content"
                )
            if self._backend_expires_entries:
                if existing is None:
                    self._own_totals[0] += entry.original_tokens
                    self._own_totals[1] += entry.compressed_tokens
                return hash_key  # no local index: Redis expires it
            # MEDIUM FIX #16: Add to eviction heap for O(log n) eviction
            heapq.heappush(self._eviction_heap, (entry.created_at, hash_key))
            heapq.heappush(
                self._expiration_heap,
                (expires_at, entry.created_at, hash_key),
            )
            if existing is not None:
                self._rebuild_heap_if_needed()

        return hash_key

    def retrieve(
        self,
        hash_key: str,
        query: str | None = None,
    ) -> CompressionEntry | None:
        """Retrieve original content by hash.

        Args:
            hash_key: Hash key returned by store().
            query: Optional query for feedback tracking.

        Returns:
            CompressionEntry if found and not expired, None otherwise.
        """
        with self._lock:
            entry = self._backend.get(hash_key)

            if entry is None:
                return None

            if entry.is_expired():
                self._backend.delete(hash_key)
                # CRITICAL FIX: Track stale heap entry
                self._mark_heap_entries_stale()
                return None

            # Track access for feedback
            entry.record_access(query)
            # Update the backend with the modified entry. Not a shared store:
            # writing the whole entry back per read races other replicas and
            # resends the original; retrieval events below stay per process.
            if self._backend_expires_entries:
                self._own_totals[2] += 1
            else:
                self._backend.set(hash_key, entry)

            # Log retrieval event
            if self._enable_feedback:
                self._log_retrieval(
                    hash_key=hash_key,
                    query=query,
                    items_retrieved=entry.original_item_count,
                    total_items=entry.original_item_count,
                    tool_name=entry.tool_name,
                    retrieval_type="full",
                    tool_signature_hash=entry.tool_signature_hash,
                )
            self._log_retrieval_payload(
                hash_key=hash_key,
                query=query,
                retrieval_type="full",
                payload=entry.original_content,
                items_retrieved=entry.original_item_count,
                total_items=entry.original_item_count,
                entry=entry,
            )

            # CRITICAL: Make a deep copy to return
            # (entry could be modified/evicted after lock release)
            # The entry contains mutable fields (search_queries list) that must be copied
            result_entry = replace(entry, search_queries=list(entry.search_queries))

        # Process feedback immediately to ensure TOIN learns in real-time
        if self._enable_feedback:
            self.process_pending_feedback()

        return result_entry

    def get_metadata(
        self,
        hash_key: str,
    ) -> dict[str, Any] | None:
        """Get metadata about a stored entry without retrieving full content.

        Useful for context tracking to know what was compressed without
        fetching the entire original content.

        Args:
            hash_key: Hash key returned by store().

        Returns:
            Dict with metadata if found and not expired, None otherwise.
        """
        with self._lock:
            entry = self._backend.get(hash_key)

            if entry is None:
                return None

            if entry.is_expired():
                self._backend.delete(hash_key)
                self._mark_heap_entries_stale()
                return None

            return {
                "hash": entry.hash,
                "tool_name": entry.tool_name,
                "original_item_count": entry.original_item_count,
                "compressed_item_count": entry.compressed_item_count,
                "query_context": entry.query_context,
                "compressed_content": entry.compressed_content,
                "original_content_preview": entry.original_content[:2000],
                "created_at": entry.created_at,
                "ttl": entry.ttl,
            }

    def _log_retrieval_payload(
        self,
        *,
        hash_key: str,
        query: str | None,
        retrieval_type: str,
        payload: str,
        items_retrieved: int,
        total_items: int,
        entry: CompressionEntry,
    ) -> None:
        event = {
            "event": "headroom_retrieve",
            "hash": hash_key,
            "retrieval_type": retrieval_type,
            "query": query,
            "items_retrieved": items_retrieved,
            "total_items": total_items,
            "tool_name": entry.tool_name,
            "tool_call_id": entry.tool_call_id,
            "compression_strategy": entry.compression_strategy,
            "tool_signature_hash": entry.tool_signature_hash,
            "original_tokens": entry.original_tokens,
            "compressed_tokens": entry.compressed_tokens,
            "original_item_count": entry.original_item_count,
            "compressed_item_count": entry.compressed_item_count,
            **_payload_for_retrieval_log(payload),
        }
        logger.info(
            "event=headroom_retrieve %s",
            json.dumps(event, ensure_ascii=False, separators=(",", ":")),
        )

    def exists(self, hash_key: str, clean_expired: bool = False) -> bool:
        """Check if a hash key exists and is not expired.

        Args:
            hash_key: The hash key to check.
            clean_expired: If True, delete the entry if expired.
                          LOW FIX #20: Default False to make this a pure check.

        Returns:
            True if the entry exists and is not expired.
        """
        with self._lock:
            entry = self._backend.get(hash_key)
            if entry is None:
                return False
            if entry.is_expired():
                # LOW FIX #20: Only delete if explicitly requested
                # This makes exists() a pure check by default
                if clean_expired:
                    self._backend.delete(hash_key)
                    # CRITICAL FIX: Track stale heap entry
                    self._mark_heap_entries_stale()
                return False
            return True

    def get_entry_status(
        self,
        hash_key: str,
        *,
        clean_expired: bool = False,
    ) -> dict[str, Any]:
        """Return availability and TTL metadata for a stored entry."""
        now = time.time()
        with self._lock:
            entry = self._backend.get(hash_key)
            if entry is None:
                return {
                    "hash": hash_key,
                    "status": "missing",
                    "default_ttl_seconds": self._default_ttl,
                }

            age_seconds = now - entry.created_at
            expires_at = entry.created_at + entry.ttl
            expired = age_seconds > entry.ttl
            status = {
                "hash": hash_key,
                "status": "expired" if expired else "available",
                "ttl_seconds": entry.ttl,
                "default_ttl_seconds": self._default_ttl,
                "created_at": entry.created_at,
                "expires_at": expires_at,
                "age_seconds": age_seconds,
            }

            if expired and clean_expired:
                self._backend.delete(hash_key)
                self._mark_heap_entries_stale()

            return status

    def get_stats(self) -> dict[str, Any]:
        """Get store statistics for monitoring."""
        if self._backend_expires_entries:
            # Totals over the store would read every replica's entries (a GET
            # each) under the lock retrievals take: a shared store reports the
            # entry count across replicas, and the totals this replica added
            # since it started ("totals_scope").
            backend_stats = self._backend.get_stats()
            with self._lock:
                original, compressed, retrievals = self._own_totals
            return {
                "entry_count": backend_stats["entry_count"],
                "max_entries": self._max_entries,
                "default_ttl_seconds": self._default_ttl,
                "total_original_tokens": original,
                "total_compressed_tokens": compressed,
                "total_retrievals": retrievals,
                "totals_scope": "this_replica",
                "event_count": len(self._retrieval_events),
                "backend": backend_stats,
            }
        with self._lock:
            # Clean expired entries
            self._clean_expired()

            # Get all entries for statistics
            entries = [entry for _, entry in self._backend.items()]
            total_original_tokens = sum(e.original_tokens for e in entries)
            total_compressed_tokens = sum(e.compressed_tokens for e in entries)
            total_retrievals = sum(e.retrieval_count for e in entries)

            # Include backend stats
            backend_stats = self._backend.get_stats()

            return {
                "entry_count": self._backend.count(),
                "max_entries": self._max_entries,
                "default_ttl_seconds": self._default_ttl,
                "total_original_tokens": total_original_tokens,
                "total_compressed_tokens": total_compressed_tokens,
                "total_retrievals": total_retrievals,
                "event_count": len(self._retrieval_events),
                "backend": backend_stats,
            }

    def get_memory_stats(self) -> ComponentStats:
        """Get memory statistics for the MemoryTracker.

        Returns:
            ComponentStats with current memory usage.
        """
        from ..memory.tracker import ComponentStats

        with self._lock:
            # Get backend stats which include bytes_used
            backend_stats = self._backend.get_stats()
            bytes_used = backend_stats.get("bytes_used", 0)

            # Add retrieval events memory
            import sys

            bytes_used += sys.getsizeof(self._retrieval_events)
            for event in self._retrieval_events:
                bytes_used += sys.getsizeof(event)

            # Add eviction heap memory
            bytes_used += sys.getsizeof(self._eviction_heap)
            bytes_used += sys.getsizeof(self._expiration_heap)

            return ComponentStats(
                name="compression_store",
                entry_count=backend_stats.get("entry_count", 0)
                if self._backend_expires_entries
                else self._backend.count(),
                size_bytes=bytes_used,
                budget_bytes=None,  # No budget set yet
                # A shared store would be read whole to count these.
                hits=0
                if self._backend_expires_entries
                else sum(1 for _, e in self._backend.items() if e.retrieval_count > 0),
                misses=0,  # CompressionStore doesn't track misses directly
                evictions=0,  # Would need to track this separately
            )

    def get_retrieval_events(
        self,
        limit: int = 100,
        tool_name: str | None = None,
    ) -> list[RetrievalEvent]:
        """Get recent retrieval events for feedback analysis.

        Args:
            limit: Maximum number of events to return.
            tool_name: Filter by tool name if specified.

        Returns:
            List of recent retrieval events (copies to prevent mutation).
        """
        with self._lock:
            # MEDIUM FIX #17: Take a slice copy immediately to avoid race conditions
            # if another thread modifies _retrieval_events after we release the lock
            events_copy = list(self._retrieval_events)

        # Filter and slice outside lock (safe since we have a copy)
        if tool_name:
            events_copy = [e for e in events_copy if e.tool_name == tool_name]

        return list(reversed(events_copy[-limit:]))

    def export_entries(self, hashes: list[str]) -> list[dict[str, Any]]:
        """The live entries for ``hashes`` as JSON-safe dicts, without counting
        a retrieval. ``SessionTrackerStore.save_state`` carries them across a
        restart so the markers it replays still resolve (:meth:`import_entries`)."""
        with self._lock:
            found = [self._backend.get(hash_key) for hash_key in hashes]
        return [asdict(e) for e in found if e is not None and not e.is_expired()]

    def import_entries(self, entries: list[CompressionEntry]) -> int:
        """Re-store :meth:`export_entries` output, each with its original expiry.

        An entry the backend still holds (a persistent backend kept it) is left
        as it is. Raises on a malformed entry. Returns the entries stored.
        """
        now = time.time()
        stored = 0
        for e in entries:
            if not all(
                isinstance(v, str) for v in (e.hash, e.original_content, e.compressed_content)
            ):
                raise ValueError(f"malformed CCR entry {e.hash!r}")
            ttl = int(e.created_at + e.ttl - now)
            if ttl <= 0 or self.exists(e.hash):
                continue
            self.store(
                e.original_content,
                e.compressed_content,
                original_tokens=e.original_tokens,
                compressed_tokens=e.compressed_tokens,
                original_item_count=e.original_item_count,
                compressed_item_count=e.compressed_item_count,
                tool_name=e.tool_name,
                tool_call_id=e.tool_call_id,
                query_context=e.query_context,
                tool_signature_hash=e.tool_signature_hash,
                compression_strategy=e.compression_strategy,
                ttl=ttl,
                explicit_hash=e.hash,
            )
            stored += 1
        return stored

    def clear(self) -> None:
        """Clear all entries. Mainly for testing."""
        with self._lock:
            self._backend.clear()
            self._retrieval_events.clear()
            self._pending_feedback_events.clear()
            self._eviction_heap.clear()  # MEDIUM FIX #16: Clear heap too
            self._expiration_heap.clear()
            self._stale_heap_entries = 0  # CRITICAL FIX: Reset stale counter
            self._stale_expiration_heap_entries = 0

    def close(self) -> None:
        """Close the storage backend and release its resources.

        A shared backend (Redis) registers its guard in the module-level
        registry; closing the store unregisters it so availability reports
        reflect the live store lifecycle instead of a detached one.
        """
        with self._lock:
            backend = getattr(self, "_backend", None)
            if backend is not None and hasattr(backend, "close"):
                try:
                    backend.close()
                except Exception:
                    pass

    def _evict_if_needed(self) -> None:
        """Evict expired, then oldest live entries until below capacity.

        MEDIUM FIX #16: Use heap for O(log n) eviction instead of O(n) scan.
        CRITICAL FIX: Track and clean stale heap entries to prevent memory leak.
        """
        # Avoid the old full backend items() scan per new-key store().
        # The expiration heap keeps cleanup proportional to expired roots.

        backend_count = self._backend.count()
        indexed_count = max(0, len(self._eviction_heap) - self._stale_heap_entries)
        at_capacity = backend_count >= self._max_entries
        if at_capacity:
            backend_revision = self._read_backend_revision()
            backend_changed = self._backend_revision_reader is not None and (
                backend_revision is None or backend_revision != self._backend_revision
            )
            if indexed_count != backend_count or backend_changed:
                self._rebuild_heap()
            else:
                self._rebuild_heap_if_needed()
            if backend_revision is not None:
                self._backend_revision = backend_revision
        else:
            self._rebuild_heap_if_needed()

        # Remove expired entries first without reporting successful compression.
        while self._expiration_heap:
            expires_at, created_at, hash_key = self._expiration_heap[0]
            if expires_at >= time.time():
                break

            entry = self._backend.get(hash_key)
            if entry is None and at_capacity:
                entry = self._backend.get(hash_key)
                if entry is None:
                    return
            heapq.heappop(self._expiration_heap)
            if (
                entry is not None
                and entry.created_at == created_at
                and self._expiration_time(entry) == expires_at
            ):
                self._backend.delete(hash_key)
                self._stale_heap_entries += 1
            elif self._stale_expiration_heap_entries > 0:
                self._stale_expiration_heap_entries -= 1
            else:
                # Backend-side TTL purges leave the matching eviction tuple stale.
                self._stale_heap_entries += 1

            if not at_capacity or self._backend.count() < self._max_entries:
                return

        if not at_capacity:
            return

        # If still at capacity, remove oldest entries using heap
        while self._backend.count() >= self._max_entries and self._eviction_heap:
            # Pop oldest from heap (O(log n))
            created_at, hash_key = heapq.heappop(self._eviction_heap)

            # Check if entry still exists and matches timestamp
            # (entry might have been deleted or replaced)
            entry = self._backend.get(hash_key)
            if entry is not None and entry.created_at == created_at:
                if not entry.is_expired() and self._enable_feedback and entry.retrieval_count == 0:
                    self._record_eviction_success(entry)
                self._backend.delete(hash_key)
                self._stale_expiration_heap_entries += 1
            else:
                # CRITICAL FIX: This was a stale entry, decrement counter
                # (we already popped it, so the stale entry is now gone)
                if self._stale_heap_entries > 0:
                    self._stale_heap_entries -= 1

    def _mark_heap_entries_stale(self) -> None:
        """Record lazy tuples invalidated by deleting or replacing an entry."""
        if self._backend_expires_entries:
            return  # no index kept for a self-expiring backend
        self._stale_heap_entries += 1
        self._stale_expiration_heap_entries += 1

    @staticmethod
    def _expiration_time(entry: CompressionEntry) -> float:
        """Return the entry expiration time, saturating numeric overflow."""
        try:
            return entry.created_at + float(entry.ttl)
        except OverflowError:
            return float("inf") if entry.ttl > 0 else float("-inf")

    def _read_backend_revision(self) -> object | None:
        """Read optional backend revision metadata without breaking stores."""
        if self._backend_revision_reader is None:
            return None
        try:
            revision: object | None = self._backend_revision_reader()
            return revision
        except Exception:
            logger.debug("CCR backend revision lookup failed", exc_info=True)
            return None

    def _rebuild_heap_if_needed(self) -> None:
        """Rebuild both indexes when either stale ratio reaches the threshold."""
        if self._backend_expires_entries:
            return  # rebuilding would scan the shared store
        heap_size = len(self._eviction_heap)
        expiration_heap_size = len(self._expiration_heap)
        stale_ratio = self._stale_heap_entries / heap_size if heap_size else 0
        stale_expiration_ratio = (
            self._stale_expiration_heap_entries / expiration_heap_size
            if expiration_heap_size
            else 0
        )
        if (
            stale_ratio >= self._heap_rebuild_threshold
            or stale_expiration_ratio >= self._heap_rebuild_threshold
        ):
            self._rebuild_heap()

    def _clean_expired(self) -> None:
        """Remove expired entries. Must be called with lock held.

        CRITICAL FIX: Track stale heap entries when deleting to prevent memory leak.
        """
        purge_expired = getattr(self._backend, "purge_expired", None)
        if callable(purge_expired):
            self._stale_heap_entries += purge_expired()
            return

        expired_keys = [key for key, entry in self._backend.items() if entry.is_expired()]
        for key in expired_keys:
            self._backend.delete(key)
            self._mark_heap_entries_stale()

    def _rebuild_heap(self) -> None:
        """Rebuild heap from current store entries. Must be called with lock held.

        CRITICAL FIX: This removes stale heap entries that accumulate when entries
        are deleted or replaced. Without this, the heap grows unboundedly.
        """
        # Reuse one snapshot so rebuilding never doubles backend enumeration.
        entries = self._backend.items()
        self._eviction_heap = [(entry.created_at, hash_key) for hash_key, entry in entries]
        self._expiration_heap = [
            (self._expiration_time(entry), entry.created_at, hash_key)
            for hash_key, entry in entries
        ]
        heapq.heapify(self._eviction_heap)
        heapq.heapify(self._expiration_heap)
        # Reset stale counter - heap is now clean
        self._stale_heap_entries = 0
        self._stale_expiration_heap_entries = 0
        logger.debug(
            "Rebuilt eviction heaps: %d entries",
            len(self._eviction_heap),
        )

    def _record_eviction_success(self, entry: CompressionEntry) -> None:
        """Record successful compression when an entry is evicted without retrieval.

        HIGH FIX: State divergence on eviction
        When an entry is evicted and was NEVER retrieved, this indicates the
        compression was fully successful - the LLM never needed the original data.
        We notify the feedback system so it can learn from this success.

        Must be called with lock held (entry data access).
        Actual feedback notification happens outside lock.

        Args:
            entry: The entry being evicted.
        """
        # Capture entry data while we have the lock
        tool_name = entry.tool_name
        sig_hash = entry.tool_signature_hash
        strategy = entry.compression_strategy

        # We can't call feedback while holding the lock (would cause deadlock)
        # Instead, queue this for deferred processing
        if sig_hash is not None and strategy is not None:
            # Create a synthetic "success" event that we'll process later
            # Use a special retrieval type to indicate this was an eviction success
            success_event = RetrievalEvent(
                hash=entry.hash,
                query=None,
                items_retrieved=0,  # No retrieval happened
                total_items=entry.original_item_count,
                tool_name=tool_name,
                timestamp=time.time(),
                retrieval_type="eviction_success",  # Special marker
                tool_signature_hash=sig_hash,
            )
            self._pending_feedback_events.append(success_event)
            logger.debug(
                "Recorded eviction success: hash=%s strategy=%s",
                entry.hash[:8],
                strategy,
            )

    def _log_retrieval(
        self,
        hash_key: str,
        query: str | None,
        items_retrieved: int,
        total_items: int,
        tool_name: str | None,
        retrieval_type: str,
        tool_signature_hash: str | None = None,
    ) -> None:
        """Log a retrieval event. Must be called with lock held."""
        event = RetrievalEvent(
            hash=hash_key,
            query=query,
            items_retrieved=items_retrieved,
            total_items=total_items,
            tool_name=tool_name,
            timestamp=time.time(),
            retrieval_type=retrieval_type,
            tool_signature_hash=tool_signature_hash,
        )

        # maxlen keeps this bounded; no trim needed here.
        self._retrieval_events.append(event)

        # Queue event for feedback processing (will be processed after lock release)
        # This is safe because process_pending_feedback() uses the lock to atomically
        # swap out the pending list before processing
        self._pending_feedback_events.append(event)

    def process_pending_feedback(self) -> None:
        """Process pending feedback events.

        Forwards events to:
        1. CompressionFeedback - for learning compression hints
        2. TelemetryCollector - for the data flywheel
        3. TOIN - for cross-user intelligence network

        This is called automatically on each retrieval to ensure the
        feedback loop operates in real-time.
        """
        from ..telemetry import get_telemetry_collector
        from ..telemetry.toin import get_toin
        from .compression_feedback import get_compression_feedback

        # Get pending events and related entry data atomically
        with self._lock:
            events = self._pending_feedback_events
            self._pending_feedback_events = []

            # Gather entry data while holding lock to avoid race conditions
            # Tuple: (event, tool_name, sig_hash, strategy, compressed_content)
            event_data: list[
                tuple[RetrievalEvent, str | None, str | None, str | None, str | None]
            ] = []
            for event in events:
                entry = self._backend.get(event.hash)
                if entry:
                    # Use the ACTUAL tool_signature_hash stored during compression
                    # This MUST match the hash used by SmartCrusher
                    event_data.append(
                        (
                            event,
                            entry.tool_name,
                            entry.tool_signature_hash,  # The correct hash!
                            entry.compression_strategy,
                            entry.compressed_content,  # For TOIN field-level learning
                        )
                    )
                else:
                    event_data.append((event, None, None, None, None))

        # Process outside lock
        if event_data:
            feedback = get_compression_feedback()
            telemetry = get_telemetry_collector()
            toin = get_toin()

            for event, _tool_name, sig_hash, strategy, compressed_content in event_data:
                # Notify feedback system (pass strategy for success rate tracking)
                feedback.record_retrieval(event, strategy=strategy)

                # Extract query fields if present
                query_fields = None
                if event.query:
                    # Extract field:value patterns
                    query_fields = re.findall(r"(\w+)[=:]", event.query)

                # Notify telemetry for data flywheel
                try:
                    if sig_hash is not None:
                        telemetry.record_retrieval(
                            tool_signature_hash=sig_hash,
                            retrieval_type=event.retrieval_type,
                            query_fields=query_fields,
                        )
                except Exception:
                    # Telemetry should never break the feedback loop
                    logger.debug("Telemetry record_retrieval failed", exc_info=True)

                # Parse compressed content to extract items for TOIN field-level learning
                retrieved_items: list[dict[str, Any]] | None = None
                if compressed_content:
                    try:
                        parsed = json.loads(compressed_content)
                        # Handle both direct arrays and wrapped arrays
                        if isinstance(parsed, list):
                            # Filter to dicts only (field learning needs dict items)
                            retrieved_items = [item for item in parsed if isinstance(item, dict)]
                        elif isinstance(parsed, dict):
                            # Check for common wrapper patterns: {"items": [...], "results": [...]}
                            for key in ("items", "results", "data", "records"):
                                if key in parsed and isinstance(parsed[key], list):
                                    retrieved_items = [
                                        item for item in parsed[key] if isinstance(item, dict)
                                    ]
                                    break
                    except (json.JSONDecodeError, TypeError):
                        # Invalid JSON - skip field learning for this retrieval
                        pass

                # Notify TOIN for cross-user learning
                try:
                    if sig_hash is not None:
                        toin.record_retrieval(
                            tool_signature_hash=sig_hash,
                            retrieval_type=event.retrieval_type,
                            query=event.query,
                            query_fields=query_fields,
                            strategy=strategy,  # Pass strategy for success rate tracking
                            retrieved_items=retrieved_items,  # For field-level learning
                        )
                except Exception:
                    # TOIN should never break the feedback loop
                    logger.debug("TOIN record_retrieval failed", exc_info=True)


# Request-scoped store (for multi-tenant SaaS: one store per request/tenant)
_request_ccr_store: ContextVar[CompressionStore | None] = ContextVar(
    "headroom_request_ccr_store", default=None
)

# Global store instance (lazy initialization)
_compression_store: CompressionStore | None = None
_store_lock = threading.Lock()


def set_request_compression_store(store: CompressionStore | None) -> None:
    """Set the compression store for the current request context.

    Used by middleware (e.g. SaaS) to provide a tenant-scoped store.
    When set, get_compression_store() returns this store instead of the global one.

    Args:
        store: CompressionStore to use for this request, or None to clear.
    """
    _request_ccr_store.set(store)


def clear_request_compression_store() -> None:
    """Clear the request-scoped compression store."""
    _request_ccr_store.set(None)


def _create_default_ccr_backend() -> CompressionStoreBackend | None:
    """Create a CCR backend from env (e.g. HEADROOM_CCR_BACKEND=redis).

    Default (env unset or "sqlite"): SQLiteBackend at workspace_dir()/ccr_store.db
    — restart-safe and shared across worker processes, which the
    session-scale 30-minute TTL assumes.
    "memory" opts back into the in-process dict. "redis" shares one store
    across replicas (HEADROOM_REDIS_URL; headroom.cache.backends.redis) unless a
    plugin registers that name. Other values load adapters via setuptools entry
    point 'headroom.ccr_backend'.
    Returns None to use InMemoryBackend.

    Stateless mode (``--stateless`` / ``HEADROOM_STATELESS``) never opens the
    SQLite file: the entries it would hold are the verbatim tool outputs that
    stateless deployments run stateless to keep off disk. The default and an
    explicit ``sqlite`` both fall back to the in-process store (retrieval then
    does not survive a restart or cross workers, which is the documented
    stateless trade-off). A named entry-point backend is still honoured — the
    operator chose it explicitly, and it is how a stateless multi-worker
    deployment gets a non-file (e.g. redis) store.
    """
    from ..paths import persistence_allowed

    backend_type = (os.environ.get("HEADROOM_CCR_BACKEND") or "").strip().lower()
    session_store = os.environ.get("HEADROOM_COMPRESS_SESSION_STORE", "").strip()
    if not backend_type and session_store:
        # Replicas sharing compress sessions share the CCR store too: a marker
        # in a replayed transcript must resolve on whichever replica serves it.
        from .backends.redis import RedisBackend

        return RedisBackend(session_store)
    if backend_type == "memory":
        return None
    if not backend_type or backend_type == "sqlite":
        if not persistence_allowed("CCR retrieval store (ccr_store.db)"):
            return None
        try:
            from .backends.sqlite import SQLiteBackend

            return SQLiteBackend()
        except Exception as e:
            logger.warning(
                "Failed to initialize SQLite CCR backend (%s); "
                "falling back to in-memory store. Retrieval will not "
                "survive proxy restarts.",
                e,
            )
            return None
    try:
        from importlib.metadata import entry_points

        all_eps = entry_points(group="headroom.ccr_backend")
        ep = next((e for e in all_eps if e.name == backend_type), None)
        if ep is None and backend_type == "redis":
            # Built in: one store for every replica behind a gateway. A plugin
            # registered as "redis" still wins, above.
            from .backends.redis import RedisBackend

            url = os.environ.get("HEADROOM_REDIS_URL", "").strip() or session_store
            if not url:
                logger.error(
                    "HEADROOM_CCR_BACKEND=redis needs HEADROOM_REDIS_URL; using the "
                    "in-process store, so a marker resolves only on the replica that made it"
                )
                return None
            return RedisBackend(url)
        if ep is None:
            logger.warning(
                "HEADROOM_CCR_BACKEND=%s but no entry point headroom.ccr_backend[%s]",
                backend_type,
                backend_type,
            )
            return None
        fn = ep.load()
        kwargs = {
            "url": os.environ.get("HEADROOM_REDIS_URL", ""),
            "tenant_prefix": os.environ.get("HEADROOM_CCR_TENANT_PREFIX", ""),
        }
        backend: CompressionStoreBackend = fn(**kwargs)
        return backend
    except Exception as e:
        # The backend's exception can echo HEADROOM_REDIS_URL (credentials included),
        # so no level logs its message; DEBUG gets describe_exception (types and frames).
        logger.warning(
            "Failed to load CCR backend %s (%s); falling back to the in-process store. "
            "Retrieval will not survive proxy restarts or cross worker processes.",
            backend_type,
            safe_id(e),
        )
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug("CCR backend %s load failure: %s", backend_type, describe_exception(e))
        return None


def get_compression_store(
    max_entries: int = 1000,
    default_ttl: int | None = None,
    backend: CompressionStoreBackend | None = None,
) -> CompressionStore:
    """Get the compression store instance.

    If a request-scoped store was set (e.g. by SaaS middleware), returns it.
    Otherwise uses lazy-initialized global singleton. Backend can be supplied
    explicitly or created from env (HEADROOM_CCR_BACKEND) when building the global.

    Args:
        max_entries: Maximum entries (only used on first call for global store).
        default_ttl: Default TTL (only used on first call for global store).
            When omitted, HEADROOM_CCR_TTL_SECONDS overrides the 1800-second default.
        backend: Custom storage backend (only used on first call for global store).
                 Defaults to InMemoryBackend if not provided; env backend used if backend is None.

    Returns:
        Request-scoped CompressionStore if set, else global CompressionStore instance.
    """
    request_store = _request_ccr_store.get()
    if request_store is not None:
        return request_store

    global _compression_store
    if _compression_store is None:
        with _store_lock:
            if _compression_store is None:
                if backend is None:
                    backend = _create_default_ccr_backend()
                effective_default_ttl = (
                    default_ttl if default_ttl is not None else _get_env_default_ttl_seconds()
                )
                _compression_store = CompressionStore(
                    max_entries=max_entries,
                    default_ttl=effective_default_ttl,
                    backend=backend,
                )
    return _compression_store


def detach_compression_store() -> None:
    """Drop the global compression store without clearing it.

    The next :func:`get_compression_store` builds a fresh store from the
    current settings. Unlike :func:`reset_compression_store`, the old store's
    entries are left as they are: nothing is deleted from its backend, so a
    SQLite file is neither written nor emptied. Used when the proxy switches to
    stateless mode at runtime. The old backend is not closed, because code
    that already holds the old store may still be using it; only its Redis
    guard is unregistered, so /health and /metrics stop reporting it.
    """
    global _compression_store

    with _store_lock:
        guard = getattr(getattr(_compression_store, "_backend", None), "_guard", None)
        if guard is not None:
            guard.close()
        _compression_store = None


def reset_compression_store() -> None:
    """Reset the global compression store. Mainly for testing."""
    global _compression_store

    with _store_lock:
        if _compression_store is not None:
            _compression_store.clear()
            if hasattr(_compression_store, "close"):
                try:
                    _compression_store.close()
                except Exception:
                    pass
        _compression_store = None
