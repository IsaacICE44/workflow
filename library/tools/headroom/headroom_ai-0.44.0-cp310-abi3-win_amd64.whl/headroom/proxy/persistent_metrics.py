"""Pure, bounded aggregate state for the durable Dashboard Lifetime view."""

from __future__ import annotations

import math
from collections.abc import Callable
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any

from headroom.config import WASTE_SIGNAL_ALIASES, WASTE_SIGNAL_KEYS

SCHEMA_VERSION = 5
MAX_PROVIDER_VALUES = 32
MAX_STACK_VALUES = 64
MAX_TRACKED_MODELS = 200
MAX_EXPOSED_MODELS = 100
MAX_LABEL_LENGTH = 128
OTHER_MODEL = "other"
# ``CostTracker.stats()`` skips keys with this prefix; an overflowing
# passthrough name must keep it or it would enter the processed-traffic totals.
PASSTHROUGH_PREFIX = "passthrough:"
OTHER_PASSTHROUGH_MODEL = PASSTHROUGH_PREFIX + OTHER_MODEL


def bounded_model_key(model: str, tracked: Any) -> str:
    """Key under which a client-supplied model name may enter a per-model map.

    ``model`` comes from the request body, so it is clipped to
    ``MAX_LABEL_LENGTH`` and a new name past ``MAX_TRACKED_MODELS`` distinct
    keys collapses into ``OTHER_MODEL`` (``OTHER_PASSTHROUGH_MODEL`` for a
    ``passthrough:`` name). ``tracked`` is the map being written.
    """
    key = model[:MAX_LABEL_LENGTH]
    if key in tracked or len(tracked) < MAX_TRACKED_MODELS:
        return key
    return OTHER_PASSTHROUGH_MODEL if key.startswith(PASSTHROUGH_PREFIX) else OTHER_MODEL


KNOWN_MISS_REASONS = frozenset({"ttl_expiry", "prefix_change", "unknown"})
# Mirrors RATE_LIMIT_SOURCES in prometheus_metrics: "headroom" is our own
# limiter refusing the request, "upstream" is the provider refusing it.
RATE_LIMIT_SOURCES = frozenset({"headroom", "upstream"})


def utc_now() -> datetime:
    """Return the current UTC time without sub-second noise in persisted state."""

    return datetime.now(timezone.utc).replace(microsecond=0)


def _to_iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _coerce_int(value: Any) -> int:
    try:
        return max(int(value), 0)
    except (TypeError, ValueError, OverflowError):
        return 0


def _coerce_float(value: Any) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return 0.0
    return result if math.isfinite(result) and result >= 0 else 0.0


def _coerce_signed_float(value: Any) -> float:
    """_coerce_float without the zero floor, for compression savings that can lose."""
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return 0.0
    return result if math.isfinite(result) else 0.0


def _label(value: Any) -> str:
    if not isinstance(value, str):
        return "other"
    value = value.strip()
    return value[:MAX_LABEL_LENGTH] if value else "other"


def _normalize_waste_signal_name(name: object) -> str:
    if not isinstance(name, str):
        return "unknown"
    normalized = WASTE_SIGNAL_ALIASES.get(name, name)
    return normalized if normalized in WASTE_SIGNAL_KEYS else "unknown"


def _model_entry(raw: Any = None) -> dict[str, Any]:
    raw = raw if isinstance(raw, dict) else {}
    return {
        "requests": _coerce_int(raw.get("requests")),
        "input_tokens": _coerce_int(raw.get("input_tokens")),
        "output_tokens": _coerce_int(raw.get("output_tokens")),
        "attempted_input_tokens": _coerce_int(raw.get("attempted_input_tokens")),
        "tokens_saved": _coerce_int(raw.get("tokens_saved")),
        "last_activity_at": raw.get("last_activity_at")
        if isinstance(raw.get("last_activity_at"), str)
        else None,
    }


def _empty_state() -> dict[str, Any]:
    return {
        "started_at": None,
        "last_activity_at": None,
        "full_fidelity_started_at": None,
        "requests": {
            "total": 0,
            "cached": 0,
            "failed": 0,
            "rate_limited": 0,
            # Who produced the failure / who refused the request. The totals
            # above stay the unlabelled figures the dashboard reads; these
            # split them the same way the Prometheus labels do, so no backend
            # reports a differently-shaped counter (issue #3696).
            "failed_by_provider": {},
            "rate_limited_by_source": {},
            "by_provider": {},
            "by_stack": {},
        },
        "tokens": {"input": 0, "output": 0, "attempted_input": 0, "saved": 0},
        "prefix_cache": {
            "requests": 0,
            "hit_requests": 0,
            "cache_read_tokens": 0,
            "cache_write_tokens": 0,
            "cache_write_5m_tokens": 0,
            "cache_write_1h_tokens": 0,
            "uncached_input_tokens": 0,
            "bust_count": 0,
            "bust_tokens": 0,
            "misses_by_reason": {},
            "by_provider": {},
        },
        # ``compression_savings_usd`` is CACHE-AWARE: what the removed tokens
        # would actually have been billed at. ``compression_savings_list_usd``
        # is the same tokens at flat list price — the upper bound, and what the
        # headline used to be. ``savings_basis`` says how soundly the first of
        # those was derived (see headroom.pricing.counterfactual).
        "cost": {
            "input_usd": 0.0,
            "compression_savings_usd": 0.0,
            "compression_savings_list_usd": 0.0,
            "cache_savings_usd": 0.0,
            "savings_basis": "unknown",
        },
        "waste_signals": {},
        "models": {"tracked": {}, "other": _model_entry()},
        "persistence": {"last_saved_at": None},
    }


def _dict_or_empty(value: Any) -> dict[Any, Any]:
    return value if isinstance(value, dict) else {}


def _blend_savings_basis(existing: Any, incoming: Any) -> str:
    """Fold one request's pricing basis into the aggregate's label.

    The aggregate is only as sound as its weakest contributing request, so the
    worst basis seen wins. ``"unknown"`` means "nothing priced yet" and is
    replaced outright rather than treated as weakest, or a fresh install would
    report ``unknown`` forever after its first request.

    Never raises, and imports the ranking lazily: ``headroom.pricing`` pulls in
    litellm (~4s) and this module is on the proxy's startup path.
    """
    incoming_label = str(incoming or "").strip()
    existing_label = str(existing or "").strip() or "unknown"
    if not incoming_label:
        return existing_label
    if existing_label == "unknown" or existing_label == incoming_label:
        return incoming_label
    try:
        from headroom.pricing.counterfactual import weakest_basis

        return weakest_basis(existing_label, incoming_label)
    except Exception:  # pragma: no cover - defensive
        return existing_label


class PersistentMetricsState:
    """In-memory Lifetime aggregate with deterministic, bounded dimensions."""

    def __init__(
        self,
        raw: dict[str, Any] | None = None,
        *,
        now: Callable[[], datetime] = utc_now,
    ) -> None:
        self._now = now
        self._state = self._normalize(raw)
        self._compact_models()

    def _normalize(self, raw: dict[str, Any] | None) -> dict[str, Any]:
        source = raw if isinstance(raw, dict) else {}
        result = _empty_state()
        for timestamp_key in ("started_at", "last_activity_at", "full_fidelity_started_at"):
            value = source.get(timestamp_key)
            if isinstance(value, str):
                result[timestamp_key] = value

        raw_requests = _dict_or_empty(source.get("requests"))
        for key in ("total", "cached", "failed", "rate_limited"):
            result["requests"][key] = _coerce_int(raw_requests.get(key))
        result["requests"]["by_provider"] = self._normalize_count_map(
            raw_requests.get("by_provider"), MAX_PROVIDER_VALUES
        )
        result["requests"]["failed_by_provider"] = self._normalize_count_map(
            raw_requests.get("failed_by_provider"), MAX_PROVIDER_VALUES
        )
        # A state file written before #3696 has no split, and back-filling the
        # legacy total into one bucket would invent history we never observed —
        # so it loads empty and only new events populate it. The unlabelled
        # ``rate_limited`` total is untouched and stays comparable across the
        # upgrade.
        result["requests"]["rate_limited_by_source"] = self._normalize_enum_map(
            raw_requests.get("rate_limited_by_source"), RATE_LIMIT_SOURCES, fallback="headroom"
        )
        result["requests"]["by_stack"] = self._normalize_count_map(
            raw_requests.get("by_stack"), MAX_STACK_VALUES
        )

        raw_tokens = _dict_or_empty(source.get("tokens"))
        for key in ("input", "output", "attempted_input", "saved"):
            result["tokens"][key] = _coerce_int(raw_tokens.get(key))

        raw_cache = _dict_or_empty(source.get("prefix_cache"))
        for key in (
            "requests",
            "hit_requests",
            "cache_read_tokens",
            "cache_write_tokens",
            "cache_write_5m_tokens",
            "cache_write_1h_tokens",
            "uncached_input_tokens",
            "bust_count",
            "bust_tokens",
        ):
            result["prefix_cache"][key] = _coerce_int(raw_cache.get(key))
        result["prefix_cache"]["by_provider"] = self._normalize_count_map(
            raw_cache.get("by_provider"), MAX_PROVIDER_VALUES
        )
        result["prefix_cache"]["misses_by_reason"] = self._normalize_enum_map(
            raw_cache.get("misses_by_reason"), KNOWN_MISS_REASONS
        )

        raw_cost = _dict_or_empty(source.get("cost"))
        for key in (
            "input_usd",
            "compression_savings_usd",
            "compression_savings_list_usd",
            "cache_savings_usd",
        ):
            coerce = (
                _coerce_signed_float if key.startswith("compression_savings") else _coerce_float
            )
            result["cost"][key] = round(coerce(raw_cost.get(key)), 6)
        # A state written before cache-aware pricing has no list column and its
        # dollars WERE list-priced, so that one figure seeds both and the
        # aggregate stays honestly labelled.
        #
        # The `has_priced_history` guard matters: a FRESH state also has no list
        # column, and labelling that "list" would tell every new install its
        # untouched $0.00 total was list-priced. Only a state that actually
        # accumulated dollars has history to migrate.
        has_priced_history = result["cost"]["compression_savings_usd"] != 0
        if "compression_savings_list_usd" in raw_cost:
            result["cost"]["savings_basis"] = str(raw_cost.get("savings_basis") or "unknown")
        elif has_priced_history:
            result["cost"]["compression_savings_list_usd"] = result["cost"][
                "compression_savings_usd"
            ]
            result["cost"]["savings_basis"] = "list"
        # Use the same canonical vocabulary for persisted and live signals so
        # aliases and old catch-all names cannot create parallel buckets.
        result["waste_signals"] = self._normalize_waste_signal_map(source.get("waste_signals"))

        raw_models = _dict_or_empty(source.get("models"))
        raw_tracked = _dict_or_empty(raw_models.get("tracked"))
        for name, entry in raw_tracked.items():
            normalized_name = self._model_name(name)
            if normalized_name == "other":
                self._merge_model_entry(result["models"]["other"], _model_entry(entry))
                continue
            result["models"]["tracked"][normalized_name] = _model_entry(entry)
        self._merge_model_entry(result["models"]["other"], _model_entry(raw_models.get("other")))
        raw_persistence = _dict_or_empty(source.get("persistence"))
        if isinstance(raw_persistence.get("last_saved_at"), str):
            result["persistence"]["last_saved_at"] = raw_persistence["last_saved_at"]
        return result

    @staticmethod
    def _normalize_count_map(raw: Any, limit: int) -> dict[str, int]:
        result: dict[str, int] = {}
        if not isinstance(raw, dict):
            return result
        for key, value in raw.items():
            label = _label(key)
            result[label] = result.get(label, 0) + _coerce_int(value)
        PersistentMetricsState._compact_count_map(result, limit)
        return result

    @staticmethod
    def _normalize_enum_map(
        raw: Any, allowed: frozenset[str], *, fallback: str = "unknown"
    ) -> dict[str, int]:
        result: dict[str, int] = {}
        if not isinstance(raw, dict):
            return result
        for key, value in raw.items():
            label = key if isinstance(key, str) and key in allowed | {fallback} else fallback
            result[label] = result.get(label, 0) + _coerce_int(value)
        return result

    @staticmethod
    def _normalize_waste_signal_map(raw: Any) -> dict[str, int]:
        result: dict[str, int] = {}
        if not isinstance(raw, dict):
            return result
        for key, value in raw.items():
            bucket = _normalize_waste_signal_name(key)
            result[bucket] = result.get(bucket, 0) + _coerce_int(value)
        return result

    @staticmethod
    def _compact_count_map(values: dict[str, int], limit: int) -> None:
        named = [key for key in values if key != "other"]
        while len(named) > limit:
            evicted = min(named, key=lambda key: (values[key], key))
            values["other"] = values.get("other", 0) + values.pop(evicted)
            named.remove(evicted)

    def _record_activity(self) -> str:
        timestamp = _to_iso(self._now())
        if self._state["started_at"] is None:
            self._state["started_at"] = timestamp
        if self._state["full_fidelity_started_at"] is None:
            self._state["full_fidelity_started_at"] = timestamp
        self._state["last_activity_at"] = timestamp
        return timestamp or ""

    @staticmethod
    def _increment_count(values: dict[str, int], label: str, limit: int) -> None:
        values[label] = values.get(label, 0) + 1
        PersistentMetricsState._compact_count_map(values, limit)

    @staticmethod
    def _model_name(value: Any) -> str:
        """Never retain the legacy unknown model bucket as a named model."""

        label = _label(value)
        return "other" if label.lower() == "unknown" else label

    @staticmethod
    def _merge_model_entry(destination: dict[str, Any], source: dict[str, Any]) -> None:
        for key in (
            "requests",
            "input_tokens",
            "output_tokens",
            "attempted_input_tokens",
            "tokens_saved",
        ):
            destination[key] += _coerce_int(source.get(key))
        if destination["last_activity_at"] is None or (
            source["last_activity_at"] is not None
            and source["last_activity_at"] > destination["last_activity_at"]
        ):
            destination["last_activity_at"] = source["last_activity_at"]

    @staticmethod
    def _model_rank(item: tuple[str, dict[str, Any]]) -> tuple[int, str, str]:
        name, entry = item
        observed_tokens = entry["input_tokens"] + entry["output_tokens"]
        return (-observed_tokens, entry["last_activity_at"] or "", name)

    def _compact_models(self) -> None:
        tracked = self._state["models"]["tracked"]
        if len(tracked) <= MAX_TRACKED_MODELS:
            return
        ranked = sorted(tracked.items(), key=self._model_rank)
        kept = dict(ranked[:MAX_EXPOSED_MODELS])
        other = self._state["models"]["other"]
        for _, entry in ranked[MAX_EXPOSED_MODELS:]:
            self._merge_model_entry(other, entry)
        self._state["models"]["tracked"] = kept

    def _record_model(
        self,
        *,
        model: str | None,
        timestamp: str,
        input_tokens: int,
        output_tokens: int,
        attempted_input_tokens: int,
        tokens_saved: int,
    ) -> None:
        name = self._model_name(model)
        models = self._state["models"]
        entry = (
            models["other"]
            if name == "other"
            else models["tracked"].setdefault(name, _model_entry())
        )
        entry["requests"] += 1
        entry["input_tokens"] += input_tokens
        entry["output_tokens"] += output_tokens
        entry["attempted_input_tokens"] += attempted_input_tokens
        entry["tokens_saved"] += tokens_saved
        entry["last_activity_at"] = timestamp
        self._compact_models()

    def record_request(
        self,
        *,
        provider: str | None,
        stack: str | None,
        model: str | None,
        input_tokens: Any = 0,
        output_tokens: Any = 0,
        attempted_input_tokens: Any = 0,
        tokens_saved: Any = 0,
        cached: bool = False,
        record_stack: bool = True,
        cache_read_tokens: Any = 0,
        cache_write_tokens: Any = 0,
        cache_write_5m_tokens: Any = 0,
        cache_write_1h_tokens: Any = 0,
        uncached_input_tokens: Any = 0,
        input_usd: Any = 0.0,
        compression_savings_usd: Any = 0.0,
        compression_savings_list_usd: Any = None,
        savings_basis: Any = None,
        cache_savings_usd: Any = 0.0,
        waste_signals: dict[str, Any] | None = None,
    ) -> None:
        """Accumulate one completed top-level request after coercing all deltas."""

        timestamp = self._record_activity()
        input_delta = _coerce_int(input_tokens)
        output_delta = _coerce_int(output_tokens)
        attempted_delta = _coerce_int(attempted_input_tokens)
        saved_delta = _coerce_int(tokens_saved)
        provider_label = _label(provider)
        stack_label = _label(stack)

        requests = self._state["requests"]
        requests["total"] += 1
        requests["cached"] += int(bool(cached))
        self._increment_count(requests["by_provider"], provider_label, MAX_PROVIDER_VALUES)
        if record_stack:
            self._increment_count(requests["by_stack"], stack_label, MAX_STACK_VALUES)

        tokens = self._state["tokens"]
        tokens["input"] += input_delta
        tokens["output"] += output_delta
        tokens["attempted_input"] += attempted_delta
        tokens["saved"] += saved_delta

        cache = self._state["prefix_cache"]
        cache["requests"] += 1
        cache["hit_requests"] += int(bool(cached))
        cache["cache_read_tokens"] += _coerce_int(cache_read_tokens)
        cache["cache_write_tokens"] += _coerce_int(cache_write_tokens)
        cache["cache_write_5m_tokens"] += _coerce_int(cache_write_5m_tokens)
        cache["cache_write_1h_tokens"] += _coerce_int(cache_write_1h_tokens)
        cache["uncached_input_tokens"] += _coerce_int(uncached_input_tokens)
        self._increment_count(cache["by_provider"], provider_label, MAX_PROVIDER_VALUES)

        cost = self._state["cost"]
        cost["input_usd"] = round(cost["input_usd"] + _coerce_float(input_usd), 6)
        cost["compression_savings_usd"] = round(
            cost["compression_savings_usd"] + _coerce_signed_float(compression_savings_usd), 6
        )
        # Defaults to the cache-aware figure when a caller supplies no ceiling,
        # which is the truthful reading of "these are the same number" for a
        # request that had no cache mix to price against.
        list_delta = (
            compression_savings_usd
            if compression_savings_list_usd is None
            else compression_savings_list_usd
        )
        cost["compression_savings_list_usd"] = round(
            _coerce_signed_float(cost.get("compression_savings_list_usd"))
            + _coerce_signed_float(list_delta),
            6,
        )
        if savings_basis:
            cost["savings_basis"] = _blend_savings_basis(cost.get("savings_basis"), savings_basis)
        cost["cache_savings_usd"] = round(
            cost["cache_savings_usd"] + _coerce_float(cache_savings_usd), 6
        )

        if isinstance(waste_signals, dict):
            for name, token_count in waste_signals.items():
                bucket = _normalize_waste_signal_name(name)
                self._state["waste_signals"][bucket] = self._state["waste_signals"].get(
                    bucket, 0
                ) + _coerce_int(token_count)

        self._record_model(
            model=model,
            timestamp=timestamp,
            input_tokens=input_delta,
            output_tokens=output_delta,
            attempted_input_tokens=attempted_delta,
            tokens_saved=saved_delta,
        )

    def record_stack(self, stack: str | None) -> None:
        """Accumulate the existing inbound stack label without adding a request."""

        if stack is None:
            return
        self._record_activity()
        self._increment_count(self._state["requests"]["by_stack"], _label(stack), MAX_STACK_VALUES)

    def record_failed(self, *, provider: str | None = None, model: str | None = None) -> None:
        """Record a failed request without changing the completed-request denominator."""

        self._record_activity()
        self._state["requests"]["failed"] += 1
        self._increment_count(
            self._state["requests"]["failed_by_provider"], _label(provider), MAX_PROVIDER_VALUES
        )

    def record_rate_limited(
        self,
        *,
        provider: str | None = None,
        model: str | None = None,
        source: str = "headroom",
    ) -> None:
        """Record a rate-limited request without redefining total request semantics.

        ``source`` is ``headroom`` (our own limiter) or ``upstream`` (the
        provider's 429); anything else is clamped to ``headroom``, which is what
        this counter meant before upstream 429s started reaching it.
        """

        self._record_activity()
        self._state["requests"]["rate_limited"] += 1
        bucket = source if source in RATE_LIMIT_SOURCES else "headroom"
        by_source = self._state["requests"]["rate_limited_by_source"]
        by_source[bucket] = by_source.get(bucket, 0) + 1

    def record_cache_bust(self, *, tokens_lost: Any = 0) -> None:
        self._record_activity()
        cache = self._state["prefix_cache"]
        cache["bust_count"] += 1
        cache["bust_tokens"] += _coerce_int(tokens_lost)

    def record_cache_miss(self, *, provider: str | None, reason: str | None) -> None:
        self._record_activity()
        bucket = reason if isinstance(reason, str) and reason in KNOWN_MISS_REASONS else "unknown"
        misses = self._state["prefix_cache"]["misses_by_reason"]
        misses[bucket] = misses.get(bucket, 0) + 1

    def set_last_saved_at(self, value: str | None) -> None:
        self._state["persistence"]["last_saved_at"] = value

    def to_dict(self) -> dict[str, Any]:
        """Return the persisted form without derived values or I/O metadata."""

        return deepcopy(self._state)

    @staticmethod
    def _percent(numerator: int, denominator: int) -> float | None:
        if denominator <= 0:
            return None
        return round(numerator / denominator * 100, 6)

    def _by_model_snapshot(self) -> dict[str, dict[str, Any]]:
        ranked = sorted(self._state["models"]["tracked"].items(), key=self._model_rank)
        visible = ranked[:MAX_EXPOSED_MODELS]
        other = _model_entry(self._state["models"]["other"])
        for _, entry in ranked[MAX_EXPOSED_MODELS:]:
            self._merge_model_entry(other, entry)
        result = {name: deepcopy(entry) for name, entry in visible}
        result["other"] = other
        return result

    def snapshot(self, *, persistence: dict[str, Any]) -> dict[str, Any]:
        """Return an API-safe aggregate and derive all percentages at read time."""

        cache = self._state["prefix_cache"]
        cache_write_total = cache["cache_write_1h_tokens"] + cache["cache_write_5m_tokens"]
        tokens = self._state["tokens"]
        return {
            "scope": "lifetime",
            "schema_version": SCHEMA_VERSION,
            "generated_at": _to_iso(self._now()),
            "started_at": self._state["started_at"],
            "last_activity_at": self._state["last_activity_at"],
            "full_fidelity_started_at": self._state["full_fidelity_started_at"],
            "requests": deepcopy(self._state["requests"]),
            "tokens": {
                **deepcopy(tokens),
                "token_savings_percent": self._percent(tokens["saved"], tokens["attempted_input"]),
            },
            "prefix_cache": {
                **deepcopy(cache),
                "cache_hit_rate": self._percent(cache["hit_requests"], cache["requests"]),
                "ttl_1h_percent": self._percent(cache["cache_write_1h_tokens"], cache_write_total),
                "ttl_5m_percent": self._percent(cache["cache_write_5m_tokens"], cache_write_total),
            },
            "cost": deepcopy(self._state["cost"]),
            "waste_signals": deepcopy(self._state["waste_signals"]),
            "by_model": self._by_model_snapshot(),
            "persistence": {
                **deepcopy(persistence),
                "last_saved_at": self._state["persistence"]["last_saved_at"],
            },
        }
